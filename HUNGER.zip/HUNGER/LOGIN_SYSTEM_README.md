# HUNGER - Login & Authentication System

## Overview
A fully functional login and sign-up system has been integrated into the HUNGER food ordering website. The system uses browser localStorage to manage user accounts and authentication state.

## Features

### 1. **Dual Form Interface**
- Toggle between Login and Sign Up forms
- Smooth transition animations
- Consistent design with the rest of the website

### 2. **Login Functionality**
- Email and password authentication
- "Remember Me" option
- Password visibility toggle
- Form validation with helpful error messages
- Forgot password link (placeholder)

### 3. **Sign Up Functionality**
- Full name, email, phone, and password fields
- Password confirmation
- Real-time password strength indicator (Weak/Medium/Strong)
- Terms & Conditions checkbox
- Phone number validation (supports international formats)
- Email format validation

### 4. **User Authentication**
- Secure password storage in localStorage
- Auto-login after successful registration
- Session persistence with "Remember Me"
- User data stored in `hungerUsers` array
- Current user stored in `currentUser` object

### 5. **Navigation Integration**
- Login button appears in all pages
- When logged in, button shows user name
- Logout button appears when user is logged in
- Account info popup on click (shows name, email, phone)

### 6. **Social Login (Placeholder)**
- Google login button
- Facebook login button
- Currently shows alert - ready for OAuth integration

## Files Created/Modified

### New Files:
1. **login.html** - Login/Sign-up page with complete UI
2. **js/login.js** - Authentication logic and form handling

### Modified Files:
1. **css/style.css** - Added comprehensive login page styles
2. **js/main.js** - Added user authentication awareness
3. **All HTML pages** - Updated navigation to include Login button

## How to Use

### For Users:

#### Creating an Account:
1. Navigate to `login.html` or click "Login" in the navigation
2. Click the "Sign Up" button
3. Fill in your details:
   - Full Name
   - Email Address
   - Phone Number
   - Password (minimum 6 characters)
   - Confirm Password
4. Check "I agree to the Terms & Conditions"
5. Click "Create Account"

#### Logging In:
1. Navigate to `login.html` or click "Login" in the navigation
2. Enter your email and password
3. Optionally check "Remember Me"
4. Click "Login"

#### Logging Out:
1. When logged in, you'll see your name in the navigation
2. Click the "Logout" button (appears next to your name)
3. Confirm logout

### For Developers:

#### LocalStorage Structure:

**hungerUsers** (Array):
```javascript
[
  {
    id: "1234567890",
    name: "John Doe",
    email: "john@example.com",
    phone: "+8801712345678",
    password: "password123",
    createdAt: "2025-12-17T10:30:00.000Z",
    orders: []
  }
]
```

**currentUser** (Object):
```javascript
{
  name: "John Doe",
  email: "john@example.com",
  phone: "+8801712345678",
  loginTime: "2025-12-17T10:30:00.000Z",
  rememberMe: true
}
```

#### API Functions (Available Globally):

```javascript
// Check if user is logged in
window.hungerAuth.isLoggedIn()

// Get current logged in user
window.hungerAuth.getCurrentUser()

// Logout user
window.hungerAuth.logout()
```

#### Validation Functions:

- `validateEmail(email)` - Validates email format
- `validatePhone(phone)` - Validates phone number (10-15 digits)
- `calculatePasswordStrength(password)` - Returns password strength

## Security Notes

⚠️ **Important**: This is a client-side authentication system using localStorage. For production use:

1. Implement server-side authentication
2. Use proper password hashing (bcrypt, Argon2, etc.)
3. Implement JWT or session tokens
4. Add HTTPS/SSL encryption
5. Implement rate limiting
6. Add CSRF protection
7. Use proper password reset flow
8. Implement OAuth properly for social logins

## Design Features

### Color Scheme:
- Primary: Red (#c62828)
- Background: Cream (#fff3e0)
- Dark: (#2e2e2e)
- White: (#ffffff)

### Responsive Design:
- Mobile-first approach
- Breakpoints at 768px and 480px
- Touch-friendly buttons
- Optimized form layout for small screens

### Animations:
- Fade-in animations on page load
- Scale animation for success icon
- Smooth transitions on all interactions
- Hover effects on buttons

## Browser Compatibility

- Chrome/Edge (latest)
- Firefox (latest)
- Safari (latest)
- Opera (latest)

Requires localStorage support (all modern browsers).

## Future Enhancements

1. Email verification
2. Password reset via email
3. Profile page with edit capabilities
4. Order history integration
5. Social login integration (OAuth)
6. Two-factor authentication
7. Account deletion
8. Password strength requirements enforcement
9. Account recovery options
10. Session timeout management

## Testing

### Test Account:
After creating an account, you can test with:
1. Create account with any valid email
2. Login with the same credentials
3. Check localStorage in browser DevTools to see stored data
4. Test logout functionality
5. Test "Remember Me" by closing and reopening browser

### Common Test Cases:
- ✅ Valid email and password
- ✅ Invalid email format
- ✅ Short password (< 6 characters)
- ✅ Password mismatch
- ✅ Duplicate email registration
- ✅ Login with non-existent email
- ✅ Wrong password
- ✅ Remember Me functionality
- ✅ Logout functionality
- ✅ Navigation updates when logged in

## Support

For issues or questions, contact: info@tetytwists.com

---

**Version**: 1.0  
**Last Updated**: December 17, 2025  
**Author**: Testy Twists Development Team

