// Food data for HUNGER online food ordering website
// Contains all menu items with their details

/**
 * Array of food items available on the menu
 * Each item contains: id, name, category, price, description, image
 */
const foods = [
  // Burgers
  {
    id: 1,
    name: "Classic Beef Burger",
    category: "burgers",
    price: 450,
    description: "Juicy beef patty with lettuce, tomato, onion, and our special sauce",
    image: "./images/burger-1.jpg"
  },
  {
    id: 2,
    name: "Cheese Deluxe Burger",
    category: "burgers",
    price: 550,
    description: "Double beef patty with melted cheddar, bacon, and crispy onions",
    image: "./images/burger-2.jpg"
  },
  {
    id: 3,
    name: "Chicken Burger",
    category: "burgers",
    price: 420,
    description: "Grilled chicken breast with avocado, lettuce, and mayo",
    image: "./images/burger-3.jpg"
  },
  {
    id: 4,
    name: "Veggie Burger",
    category: "burgers",
    price: 380,
    description: "Plant-based patty with fresh vegetables and special sauce",
    image: "./images/burger-4.jpg"
  },

  // Pizza
  {
    id: 5,
    name: "Margherita Pizza",
    category: "pizza",
    price: 650,
    description: "Classic tomato sauce, fresh mozzarella, and basil",
    image: "./images/pizza-1.jpg"
  },
  {
    id: 6,
    name: "Pepperoni Pizza",
    category: "pizza",
    price: 750,
    description: "Loaded with pepperoni, mozzarella, and tomato sauce",
    image: "./images/pizza-2.jpg"
  },
  {
    id: 7,
    name: "BBQ Chicken Pizza",
    category: "pizza",
    price: 800,
    description: "Grilled chicken, BBQ sauce, red onions, and cilantro",
    image: "./images/pizza-3.jpg"
  },
  {
    id: 8,
    name: "Vegetarian Pizza",
    category: "pizza",
    price: 700,
    description: "Bell peppers, mushrooms, olives, onions, and tomatoes",
    image: "./images/pizza-4.jpg"
  },

  // Pasta
  {
    id: 9,
    name: "Spaghetti Carbonara",
    category: "pasta",
    price: 520,
    description: "Creamy sauce with bacon, parmesan, and black pepper",
    image: "./images/pasta-1.jpg"
  },
  {
    id: 10,
    name: "Penne Arrabbiata",
    category: "pasta",
    price: 480,
    description: "Spicy tomato sauce with garlic and red chili flakes",
    image: "./images/pasta-2.jpg"
  },
  {
    id: 11,
    name: "Fettuccine Alfredo",
    category: "pasta",
    price: 580,
    description: "Rich and creamy parmesan sauce with fettuccine pasta",
    image: "./images/pasta-3.jpg"
  },
  {
    id: 12,
    name: "Lasagna",
    category: "pasta",
    price: 620,
    description: "Layers of pasta, meat sauce, and melted cheese",
    image: "./images/pasta-4.jpg"
  },

  // Salads
  {
    id: 13,
    name: "Caesar Salad",
    category: "salads",
    price: 350,
    description: "Romaine lettuce, croutons, parmesan, and Caesar dressing",
    image: "./images/salad-1.jpg"
  },
  {
    id: 14,
    name: "Greek Salad",
    category: "salads",
    price: 400,
    description: "Tomatoes, cucumbers, olives, feta cheese, and olive oil",
    image: "./images/salad-2.jpg"
  },
  {
    id: 15,
    name: "Garden Salad",
    category: "salads",
    price: 320,
    description: "Mixed greens, tomatoes, cucumbers, and balsamic vinaigrette",
    image: "./images/salad-3.jpg"
  },
  {
    id: 16,
    name: "Chicken Avocado Salad",
    category: "salads",
    price: 480,
    description: "Grilled chicken, avocado, mixed greens, and honey mustard",
    image: "./images/salad-4.jpg"
  },

  // Desserts
  {
    id: 17,
    name: "Chocolate Cake",
    category: "desserts",
    price: 280,
    description: "Rich chocolate cake with chocolate frosting",
    image: "./images/dessert-1.jpg"
  },
  {
    id: 18,
    name: "Cheesecake",
    category: "desserts",
    price: 320,
    description: "Creamy New York style cheesecake with berry compote",
    image: "./images/dessert-2.jpg"
  },
  {
    id: 19,
    name: "Tiramisu",
    category: "desserts",
    price: 320,
    description: "Classic Italian dessert with coffee and mascarpone",
    image: "./images/dessert-3.jpg"
  },
  {
    id: 20,
    name: "Ice Cream Sundae",
    category: "desserts",
    price: 250,
    description: "Vanilla ice cream with chocolate sauce and whipped cream",
    image: "./images/dessert-4.jpg"
  },

  // Drinks
  {
    id: 21,
    name: "Coca Cola",
    category: "drinks",
    price: 120,
    description: "Classic Coca Cola soft drink",
    image: "./images/drink-1.jpg"
  },
  {
    id: 22,
    name: "Fresh Orange Juice",
    category: "drinks",
    price: 200,
    description: "Freshly squeezed orange juice",
    image: "./images/drink-2.jpg"
  },
  {
    id: 23,
    name: "Iced Coffee",
    category: "drinks",
    price: 160,
    description: "Cold brew coffee with ice",
    image: "./images/drink-3.jpg"
  },
  {
    id: 24,
    name: "Lemonade",
    category: "drinks",
    price: 140,
    description: "Homemade fresh lemonade",
    image: "./images/drink-4.jpg"
  }
];

/**
 * Get all unique categories from the foods array
 * @returns {Array} Array of unique category names
 */
function getCategories() {
  const categories = foods.map(food => food.category);
  return [...new Set(categories)];
}

/**
 * Get foods by category
 * @param {string} category - The category to filter by
 * @returns {Array} Array of food items in the specified category
 */
function getFoodsByCategory(category) {
  if (category === 'all') {
    return foods;
  }
  return foods.filter(food => food.category === category);
}

/**
 * Get a single food item by ID
 * @param {number} id - The ID of the food item
 * @returns {Object|undefined} The food item or undefined if not found
 */
function getFoodById(id) {
  return foods.find(food => food.id === id);
}
